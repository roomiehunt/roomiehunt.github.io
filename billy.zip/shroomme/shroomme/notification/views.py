from django.shortcuts import render

from .models import Notification


# Create your views here.
def show_notification(request):
	result = Notification.objects.filter(user=request.user)
	context = {"notification_list":result}
	return render(request,"show_notification.html",context)