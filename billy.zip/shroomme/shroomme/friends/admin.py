from django.contrib import admin
from .models import Friends
# Register your models here.
admin.site.register(Friends)