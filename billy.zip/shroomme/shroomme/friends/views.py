from constants.constants import constants,gethome
from django.shortcuts import render,redirect
from django.views.decorators.csrf import requires_csrf_token

#-----------MODELS IMPORT-----------------------------------#
from .models import Friends
from django.contrib.auth.models import User
from userprofile.models import Profile
from notification.models import Notification


# Create your views here.

@requires_csrf_token
def add_friend(request):
	if request.method != 'POST':
		return redirect(gethome())
	else:			
		print "HELLO I AM AT AN AJAX CALL AT FRIENDS.VIEW.add_friend"
		print request.POST
		if "user2" in request.POST:
#			print request.POST["user2"]
			user2_id = request.POST["user2"]
			Profile2_object = Profile.objects.filter(id=user2_id).values()
			user2_key = Profile2_object[0][u'user_id']
			user2 = User.objects.filter(id=user2_key)[0]
			user1 = request.user
			friend_object = Friends(user1=user1,user2=user2,status = "P")
			message = str(user1.first_name) + " " + str(user2.last_name) + "wants to be friends with you" 
			notification_object = Notification(user=user2,message=message,read=False)
			friend_object.save()
			notification_object.save()
		return redirect(gethome())
