from django.db import models
from constants.constants import constants
from django.conf import settings
from django.contrib.auth.models import User



# Create your models here.
class Friends(models.Model):
	user1 = models.ForeignKey(settings.AUTH_USER_MODEL,blank = False,null = False)
	user2 = models.ForeignKey(settings.AUTH_USER_MODEL,blank = False,null = False,related_name="friends+")
	status = models.CharField(max_length=1,choices=constants.FRIEND_STATUS,default='U')
	created = models.DateTimeField(auto_now_add=True)