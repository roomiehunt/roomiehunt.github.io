#----------------------------------------------CONSTANTS OF THE PROJECT IS STORED HERE------------------------------------------------------#
#---------------ALL APP NAMES START WITH LOWER LETTER-------------#
#---------------ALL MODEL NAMES START WITH CAPITALS---------------#

class constants():
	GENDER_CHOICES = (
		('M','Male'),
		('F','Female'),
		('U','Unspecified'),
	)
	FRIEND_STATUS = (
		('U','Unfriends'),
		('F','Friends'),
		('P','Pending'),
		('B','Blocked'),
	)

def gethome():
	from shroomme.views import home
	return home